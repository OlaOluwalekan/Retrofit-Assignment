package com.icode.retrofit;

import android.app.*;
import android.os.*;
import android.widget.*;
import retrofit2.*;
import retrofit2.converter.gson.*;
import java.util.*;
import android.widget.Toast.*;
import android.support.v7.widget.*;
import android.view.*;

public class MainActivity extends Activity  {
	RecyclerView recyclerView;
	ProgressBar progressBar;
	LinearLayoutManager layoutManager;
	PostAdapter adapter;
	List<Post> postList = new ArrayList<>();
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		recyclerView = findViewById(R.id.recyclerView);
		progressBar = findViewById(R.id.progressBar);
		layoutManager = new LinearLayoutManager(this);
		recyclerView.setLayoutManager(layoutManager);
		adapter = new PostAdapter(postList);
		recyclerView.setAdapter(adapter);
		
		fetchPost();
	}

	private void fetchPost() {
		progressBar.setVisibility(View.VISIBLE);
		RetrofitClient.getRetrofitClient().getPosts().enqueue(new Callback<List<Posts>>() {
				@Override
				public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {
					if(response.isSuccessful() && response.body() != null) {
						postList.addAll(response.body());
						adapter.notifyDataSetChanged();
						progressBar.setVisibility(View.GONE);
					}
				}
				
				@Override
				public void onFailure(Call<List<Post>> call, Throwable t) {
					progressBar.setVisibility(View.GONE);
					Toast.makeText(MainActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
				}
		});
	}
}
