package com.icode.retrofit;
import android.support.v7.widget.*;
import java.util.*;
import android.support.annotation.*;
import android.view.*;
import android.widget.*;
import android.view.View.*;

public class PostAdapter extends RecyclerView.Adapter<PostAdapter.ViewHolder> {
	private List<Post> postList;
	
	public PostAdapter(List<Post> postList) {
		this.postList = postList;
	}

	@NonNull
	@Override
	public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
		View view = LayoutInflater.from(parent.getContext())
					.inflate(R.layout.list_item, parent, false);
		return new ViewHolder(view);
	}

	@Override
	public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
		holder.tvName.setText(postList.get(position).getName());
		holder.tvStatus.setText(postList.get(position).getStatus());
		holder.tvSpecies.setText(postList.get(position).getSpecies());
		holder.imgImage.setImageResource(postList.get(position).getUrl());
		
	}

	@Override
	public int getItemCount() {
		return postList.size();
	}
	
	public class ViewHolder extends RecyclerView.ViewHolder {
		TextView tvName;
		TextView tvStatus;
		TextView tvSpecies;
		ImageView imgImage;
		
		public ViewHolder(@NonNull View itemView) {
			super(itemView);
			
			tvName = itemView.findViewById(R.id.tvName);
			tvStatus = itemView.findViewById(R.id.tvStatus);
			tvSpecies = itemView.findViewById(R.id.tvSpecies);
			imgImage = itemView.findViewById(R.id.img_image);
		}
	}
}
