package com.icode.retrofit;
import retrofit2.*;
import java.util.*;
import retrofit2.http.*;

public interface JasonPlaceHolderApi {
	
	@GET("/characters")
	Call<List<Post>> getPosts();
}
