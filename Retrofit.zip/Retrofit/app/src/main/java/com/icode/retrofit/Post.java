package com.icode.retrofit;
import com.google.gson.annotations.*;
import java.net.*;

public class Post {
	private String name;
	
	private String status;
	
	private String species;
	
	private int url;
	
	public Post (String name, String status, String species, int url) {
		this.name = name;
		this.status = status;
		this.species = species;
		this.url = url;
	}

	public String getName() {
		return name;
	}
	
	public String getStatus() {
		return status;
	}
	
	public String getSpecies() {
		return species;
	}
	
	public int getUrl() {
	 return url;
	 }
}
